﻿namespace HashCode
{
    public class GainCacheServer
    {
        public int CacheServerID;
        public int Gain;
    }
}
