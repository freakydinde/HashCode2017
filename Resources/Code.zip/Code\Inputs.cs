﻿namespace HashCode
{
    using System;
    using System.IO;

    /// <summary>inputs used for tests</summary>
    public static class Inputs
    {
        private static string resourcesFolder;

        public static string ResourcesFolder
        {
            get
            {
                if (resourcesFolder == null)
                {
                    resourcesFolder = AppDomain.CurrentDomain.BaseDirectory;

                    while (!Directory.Exists(Path.Combine(resourcesFolder, "Resources")))
                    {
                        resourcesFolder = Directory.GetParent(resourcesFolder).FullName;
                    }

                    resourcesFolder = Path.Combine(resourcesFolder, "Resources");
                }

                return resourcesFolder;
            }
        }
        
        public static string InKitten
        {
            get
            {
                return Path.Combine(Inputs.ResourcesFolder, "kittens.in");
            }
        }

        public static string InMeAtTheZoo
        {
            get
            {
                return Path.Combine(Inputs.ResourcesFolder, "me_at_the_zoo.in");
            }
        }

        public static string InTrendingToday
        {
            get
            {
                return Path.Combine(Inputs.ResourcesFolder, "trending_today.in");
            }
        }

        public static string InVideosWorthSpreading
        {
            get
            {
                return Path.Combine(Inputs.ResourcesFolder, "videos_worth_spreading.in");
            }
        }
    }
}