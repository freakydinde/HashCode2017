﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace HashCode
{
    public class Request
    {
        public int EndPointID;
        public int NumAsked;
        public int VideoID;   
    }
}