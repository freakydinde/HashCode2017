﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashCode
{
    public class Video
    {
        public int ID;

        public int Size;

        public Video(int id, int size)
        {
            this.ID = id;
            this.Size = size;
        }
    }
}
