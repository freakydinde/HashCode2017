﻿namespace HashCode
{
    public class Video
    {
        public int ID;

        public int Size;

        public Video(int id, int size)
        {
            this.ID = id;
            this.Size = size;
        }
    }
}